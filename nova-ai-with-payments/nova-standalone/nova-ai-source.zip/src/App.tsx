import { useState, useCallback } from 'react';
import { useNova } from './nova/useNova';
import { Header } from './nova/ui/Header';
import { AgentList } from './nova/ui/AgentList';
import { ChatPanel } from './nova/ui/ChatPanel';
import { ExecutionPanel } from './nova/ui/ExecutionPanel';
import { ResultPanel } from './nova/ui/ResultPanel';

function App() {
  const { state, submitTask, stop, retry, reset, allAgents } = useNova();
  const [showResult, setShowResult] = useState(false);

  const handleSubmit = useCallback(async (request: string) => {
    setShowResult(false);
    await submitTask(request);
    setShowResult(true);
  }, [submitTask]);

  const handleRetry = useCallback(() => {
    setShowResult(false);
    retry();
  }, [retry]);

  const handleCopy = useCallback(() => {
    if (state.finalOutput) {
      navigator.clipboard.writeText(state.finalOutput.content);
    }
  }, [state.finalOutput]);

  const handleExport = useCallback(() => {
    if (!state.finalOutput) return;
    const blob = new Blob([state.finalOutput.content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nova-output-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  }, [state.finalOutput]);

  return (
    <div className="h-screen flex flex-col bg-mesh text-slate-100 overflow-hidden">
      <Header />

      <div className="flex-1 flex overflow-hidden">
        {/* LEFT — Agent list */}
        <aside className="w-64 lg:w-72 shrink-0 border-r border-indigo-500/10 glass-panel-strong hidden md:flex flex-col">
          <AgentList
            agents={allAgents}
            agentStates={state.agentStates}
            masterOnline={true}
            isRunning={state.isRunning}
          />
        </aside>

        {/* CENTER — Chat / Task editor */}
        <main className="flex-1 flex flex-col min-w-0 border-r border-indigo-500/10">
          {showResult && state.finalOutput ? (
            <ResultPanel
              output={state.finalOutput}
              onRetry={handleRetry}
              onCopy={handleCopy}
              onExport={handleExport}
            />
          ) : (
            <ChatPanel
              state={state}
              onSubmit={handleSubmit}
              onStop={stop}
              onRetry={handleRetry}
              onCopy={handleCopy}
              onExport={handleExport}
            />
          )}
        </main>

        {/* RIGHT — Live execution */}
        <aside className="w-72 lg:w-80 shrink-0 glass-panel-strong hidden lg:flex flex-col">
          <ExecutionPanel state={state} />
        </aside>
      </div>

      {/* Mobile bottom bar for agent status */}
      <div className="md:hidden glass-panel-strong border-t border-indigo-500/10 px-4 py-2 flex items-center gap-3 overflow-x-auto">
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-xs text-green-400 font-medium">Master Online</span>
        </div>
        <div className="w-px h-4 bg-slate-700 shrink-0" />
        <span className="text-xs text-slate-400 shrink-0">
          {Object.values(state.agentStates).filter((a) => a.status === 'running').length} running
        </span>
        <span className="text-xs text-slate-400 shrink-0">
          {Object.values(state.agentStates).filter((a) => a.status === 'completed').length} completed
        </span>
      </div>
    </div>
  );
}

export default App;
